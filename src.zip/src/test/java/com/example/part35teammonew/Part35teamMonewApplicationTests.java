package com.example.part35teammonew;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Part35teamMonewApplicationTests {

	@Test
	void contextLoads() {
	}

}
