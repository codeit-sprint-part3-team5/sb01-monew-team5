package com.example.part35teammonew.domain.interest.Enum;

public enum SortBy {
  NAME,
  SUBSCRIBER_COUNT
}
