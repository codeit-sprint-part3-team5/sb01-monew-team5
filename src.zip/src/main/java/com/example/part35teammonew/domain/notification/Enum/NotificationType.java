package com.example.part35teammonew.domain.notification.Enum;

public enum NotificationType {
  NEWS, COMMENT
}
