package com.example.part35teammonew.domain.article.entity;

public enum Direction {
  ASC, DESC;
}
