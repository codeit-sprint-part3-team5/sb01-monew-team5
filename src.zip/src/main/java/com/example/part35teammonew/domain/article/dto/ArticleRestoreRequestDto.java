package com.example.part35teammonew.domain.article.dto;

import lombok.Data;

@Data
public class ArticleRestoreRequestDto {
  private String from;
  private String to;
}
