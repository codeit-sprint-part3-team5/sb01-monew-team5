package com.example.part35teammonew.domain.article.entity;

public enum SortField {
  publishDate, commentCount, viewCount
}
